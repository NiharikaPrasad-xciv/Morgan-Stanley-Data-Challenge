# Elasticsearch How-To

![dashboard](https://i.imgur.com/BEbtdo5.png)

Please read the Wiki [here](https://github.com/twintproject/twint/wiki/Elasticsearch)
